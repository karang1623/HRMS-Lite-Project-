# HRMS Lite – Full Stack Assignment

## Overview
A lightweight Human Resource Management System (HRMS Lite) built as per the assignment requirements.

## Features
- Employee Management (Add, List, Delete)
- Attendance Management (Mark Present/Absent, View Records)
- RESTful APIs
- Server-side validation
- Simple professional UI

## Tech Stack
- Backend: Python (Flask)
- Database: SQLite
- Frontend: HTML, CSS, JavaScript

## Run Locally
```bash
pip install flask
python app.py
```

## Assumptions / Limitations
- Single admin user (no authentication)
- No payroll or leave management