from flask import Flask, request, jsonify, render_template
import sqlite3, re
from datetime import date

app = Flask(__name__)
DB = "hrms.db"

def get_db():
    return sqlite3.connect(DB)

def init_db():
    db = get_db()
    db.execute("""CREATE TABLE IF NOT EXISTS employees (
        emp_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        department TEXT NOT NULL
    )""")
    db.execute("""CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        emp_id TEXT,
        att_date TEXT,
        status TEXT,
        FOREIGN KEY(emp_id) REFERENCES employees(emp_id)
    )""")
    db.commit()

@app.route("/")
def ui():
    return render_template("index.html")

# ---------- Employee APIs ----------
@app.route("/api/employees", methods=["GET"])
def list_employees():
    db = get_db()
    rows = db.execute("SELECT * FROM employees").fetchall()
    return jsonify(rows)

@app.route("/api/employees", methods=["POST"])
def add_employee():
    data = request.json
    if not all(k in data for k in ("emp_id","name","email","department")):
        return {"error":"Missing fields"}, 400
    if not re.match(r"[^@]+@[^@]+\.[^@]+", data["email"]):
        return {"error":"Invalid email"}, 400
    try:
        db = get_db()
        db.execute("INSERT INTO employees VALUES (?,?,?,?)",
                   (data["emp_id"], data["name"], data["email"], data["department"]))
        db.commit()
    except:
        return {"error":"Duplicate employee ID"}, 409
    return {"message":"Employee added"}, 201

@app.route("/api/employees/<emp_id>", methods=["DELETE"])
def delete_employee(emp_id):
    db = get_db()
    db.execute("DELETE FROM employees WHERE emp_id=?", (emp_id,))
    db.commit()
    return {"message":"Deleted"}

# ---------- Attendance APIs ----------
@app.route("/api/attendance", methods=["POST"])
def mark_attendance():
    data = request.json
    db = get_db()
    db.execute("INSERT INTO attendance (emp_id, att_date, status) VALUES (?,?,?)",
               (data["emp_id"], data.get("date", str(date.today())), data["status"]))
    db.commit()
    return {"message":"Attendance marked"}, 201

@app.route("/api/attendance/<emp_id>", methods=["GET"])
def view_attendance(emp_id):
    db = get_db()
    rows = db.execute("SELECT att_date,status FROM attendance WHERE emp_id=?", (emp_id,)).fetchall()
    return jsonify(rows)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)